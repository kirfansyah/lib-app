<?php require_once __DIR__ . "/../../../model/master/user/get_group_user.php"; ?>
<?php require_once __DIR__ . "/../../templates/header.php"; ?>
<?php require_once __DIR__ . "/../../templates/navbar.php"; ?>
<?php require_once __DIR__ . "/../../templates/sidebar.php"; ?>


<!-- Content -->
<div class="page-wrapper pagehead">
    <div class="content">
        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="page-title"><?= formatUrlLabel($main_page) . ' ' . formatUrlLabel($sub_page) ?></h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= $baseUrl ?>"><?= formatUrlLabel($main_page) ?? 'Dashboard' ?></a></li>
                        <li class="breadcrumb-item active"><?= formatUrlLabel($sub_page) ?? '' ?></li>
                    </ul>
                </div>
            </div>

            <div class="page-btn">
                <a id="add" href="#" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#create"><img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add Buku</a>
            </div>
        </div>
        <!-- isi content -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <!-- <div class="card-header">
                        <h4 class="card-title">Default Datatable</h4>
                        <p class="card-text">
                            This is the most basic example of the datatables with zero configuration. Use the <code>.datatable</code> class to initialize datatables.
                        </p>
                    </div> -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table  datanew " id="userTable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Judul Buku</th>
                                        <th>Penulis</th>
                                        <th>Penerbit</th>
                                        <th>Tahun Terbit</th>
                                        <th>Kategori</th>
                                        <th>Stok</th>
                                        <th>Create By</th>
                                        <th>Update By</th>
                                        <th>Is Active</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- akhir isi content  -->
        <!-- End Of Content -->


        <!-- Modal Add Data -->

        <!-- Modal -->
        <div class="modal fade" id="create" tabindex="-1" aria-labelledby="create" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-lg modal-dialog-centered d-flex justify-content-center" role="document">
                <form action="" id="user-data">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Create</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>UID</label>
                                        <input name="uid" id="uid" type="text" class="form-control w-300" required autocomplete="off" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Judul</label>
                                        <input name="judul_buku" id="judul_buku" type="text" class="form-control w-300" required autocomplete="off">
                                        <input name="id_buku" id="id_buku" type="hidden" class="form-control w-300" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Penulis</label>
                                        <input name="penulis" id="penulis" type="text" class="form-control w-300" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Penerbit</label>
                                        <input name="penerbit" id="penerbit" type="text" class="form-control w-300" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Tahun Terbit</label>
                                        <input name="tahun_terbit" id="tahun_terbit" type="number" class="form-control w-300" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Kategori</label>
                                        <select name="id_kategori" id="id_kategori" class="form-control w-300" required>
                                            <option>-Choose-</option>
                                            <option value="1">Aktif</option>
                                            <option value="0">Non-aktif</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label>Stok</label>
                                        <input name="stok" id="stok" type="number" class="form-control w-300" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label>Active</label>
                                        <select name="is_active" id="is_active" class="form-control w-300" required>
                                            <option>-Choose-</option>
                                            <option value="1">Aktif</option>
                                            <option value="0">Non-aktif</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center mt-3">
                                <a class="btn btn-submit me-2">Submit</a>
                                <a class="btn btn-cancel" data-bs-dismiss="modal">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- End Of Modal Add Data -->

        <?php require_once __DIR__ . "/../../templates/footbar.php"; ?>
        <!-- Javascript -->

        <script>
            $(document).ready(function() {
                getBookCategories()

                if ($.fn.DataTable.isDataTable('#userTable')) {
                    $('#userTable').DataTable().destroy(); // Hancurkan DataTable jika sudah ada
                }

                $('#userTable').DataTable({
                    "processing": false,
                    "serverSide": false,
                    "lengthChange": false, // Menyembunyikan "Show per page"
                    "ajax": {
                        "url": "get-buku",
                        "type": "GET",
                        "dataSrc": function(json) {
                            console.log("Response Data:", json); // Log ke browser console
                            if (json.error) {
                                console.error("Error:", json.error);
                            }
                            return json.data;
                        },
                        "error": function(xhr, status, error) {
                            console.error("AJAX Error:", status, error);
                        }
                    },
                });

            });




            $(document).on('click', '.btn-submit', function() {

                var isValid = true;

                // Loop setiap input di dalam form
                $('#user-data input, #user-data select').each(function() {
                    if (($(this).val().trim() === '' || $(this).val() === '-Choose-') && $(this).attr('name') != 'id_buku') {
                        isValid = false;
                        $(this).addClass('is-invalid'); // Tambahkan efek merah jika kosong
                    } else {
                        $(this).removeClass('is-invalid'); // Hapus efek merah jika diisi
                    }
                });

                if (!isValid) {
                    toastr.error('Harap isi semua field!', 'Error', {
                        closeButton: true,
                        progressBar: true,
                        positionClass: 'toast-top-right',
                        timeOut: 3000
                    });
                    return; // Hentikan proses jika ada field kosong
                }

                var action = $(this).attr('action')
                // console.log(action);

                var formData = $('#user-data').serialize()
                var id = $('#id_buku').val()
                if (action == 'add') {
                    addData(formData)
                }

                if (action == 'update') {
                    updateData(formData)
                }



            })


            $(document).on('click', '#add', function(e) {
                e.preventDefault()
                $('#user-data').trigger("reset");
                $('.modal-title').text('Create')
                $('.btn-submit').attr('action', 'add')
            })

            $(document).on('click', '.edit-data', function(e) {
                e.preventDefault()
                var q = $(this)
                var id = q.closest('tr').find('.edit-data').data('id')
                $('#user-data').trigger("reset");
                $('.modal-title').text('Update')
                $('.btn-submit').attr('action', 'update')
                console.log('id :', id);



                $.ajax({
                    url: "get-buku-by-id", // Pastikan path sudah benar
                    type: "POST",
                    data: {
                        id_buku: id
                    },
                    dataType: "json",
                    success: function(response) {
                        console.log(response);


                        $('#id_buku').val('')
                        $('#judul_buku').val('')
                        $('#penulis').val('')
                        $('#penerbit').val('')
                        $('#tahun_terbit').val('')
                        $('#id_kategori').val('')
                        $('#stok').val('')
                        $('#is_active').val('').trigger('change')

                        if (response.status === "success") {

                            $('#uid').val(response.data.uid)
                            $('#id_buku').val(response.data.id_buku)
                            $('#judul_buku').val(response.data.judul_buku)
                            $('#penulis').val(response.data.penulis)
                            $('#penerbit').val(response.data.penerbit)
                            $('#tahun_terbit').val(response.data.tahun_terbit)
                            $('#stok').val(response.data.stok)
                            $('#id_kategori').val(response.data.id_kategori).trigger('change');
                            $('#is_active').val(response.data.is_active).trigger('change');

                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });

            })

            $(document).on('click', '.delete-data', function(e) {
                e.preventDefault()
                var q = $(this)
                var id = q.closest('tr').find('.delete-data').data('id')
                console.log('ini id :', id);

                if (!id) {
                    Swal.fire("Error!", "ID tidak ditemukan!", "error");
                    return;
                }

                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Yes, delete it!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "delete-buku",
                            type: "POST",
                            data: {
                                id_buku: id
                            },
                            dataType: "json",
                            success: function(response) {
                                if (response.status === "success") {
                                    $('#create').modal('hide'); // Tutup modal
                                    $('#userTable').DataTable().ajax.reload(null, false); // Reload tanpa reset paging

                                    Swal.fire(
                                        'Berhasil!',
                                        'Data berhasil dihapus.',
                                        'success'
                                    );

                                    $('#user-data')[0].reset(); // Reset form setelah submit
                                } else {
                                    Swal.fire(
                                        'Gagal!',
                                        response.message,
                                        'error'
                                    );
                                }
                            },
                            error: function(xhr, status, error) {
                                console.log(xhr.responseText);
                            }
                        });
                    }
                });

            })


            function addData(formData) {
                $.ajax({
                    url: "add-buku", // Pastikan path sudah benar
                    type: "POST",
                    data: formData,
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "success") {
                            $('#create').modal('hide'); // Tutup modal
                            $('#userTable').DataTable().ajax.reload(null, false); // Reload tanpa reset paging

                            Swal.fire({
                                title: "Success!",
                                text: "Data berhasil disimpan.",
                                icon: "success"
                            });

                        } else {
                            // alert(response.message);
                            Swal.fire({
                                title: "Error!",
                                text: response.message,
                                icon: "error"
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            }


            function updateData(formData) {
                $.ajax({
                    url: "update-buku", // Pastikan path sudah benar
                    type: "POST",
                    data: formData,
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "success") {
                            $('#create').modal('hide'); // Tutup modal
                            $('#userTable').DataTable().ajax.reload(null, false); // Reload tanpa reset paging

                            Swal.fire({
                                title: "Success!",
                                text: "Data berhasil diupdate.",
                                icon: "success"
                            });

                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });

            }



            function getBookCategories() {
                $.ajax({
                    url: "get-kategori-buku", // Pastikan path sudah benar
                    type: "GET",
                    dataType: "json",
                    success: function(response) {
                        // console.log('bbb ', response);

                        if (response.status === "success") {
                            var opt = `<option>-Choose-</option>`
                            $.each(response.data, function(i, v) {
                                opt += `<option value="${v.id_kategori}">${v.nama_kategori}</option>`
                            })

                            $('#id_kategori').html(opt)

                        } else {
                            alert(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            }

            let firstLoad = true;
            let lastID = null;
            const modalCreate = new bootstrap.Modal(document.getElementById('create'));

            function emptyField() {
                $('#id_buku').val('')
                $('#judul_buku').val('')
                $('#penulis').val('')
                $('#penerbit').val('')
                $('#tahun_terbit').val('')
                $('#id_kategori').val('')
                $('#stok').val('')
                $('#is_active').val('').trigger('change')
            }

            function getRFID() {
                $.ajax({
                    url: "/lib-app/rfid-get-master-buku",
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        console.log('data: ', data);

                        // 🔥 skip hasil pertama saat load halaman
                        if (firstLoad) {
                            firstLoad = false;
                            return;
                        }

                        if (data && data.uid !== lastID) {
                            autoMode = true;
                            emptyField(); // reset dulu

                            $("#uid").val(data.uid); // isi UID

                            $('.modal-title').text('Create')
                            $('.btn-submit').attr('action', 'add')

                            // modalCreate.show();
                            modalCreate.show();
                            // setTimeout(() => {
                            // }, 200);

                            lastID = data.id;
                        }
                    },
                    complete: function() {
                        setTimeout(getRFID, 1000);
                    }
                });
            }

            getRFID();
        </script>

        <!-- End Of Javascript -->
        <?php require_once __DIR__ . "/../../templates/footbarend.php"; ?>