<?php
require_once __DIR__ . "/../../../config/database.php";
require_once __DIR__ . '/../../../config/functions.php';
session_start();

$nama_member = $_POST['nama_member'];
$email       = $_POST['email'];
$no_hp       = $_POST['no_hp'];
$alamat      = $_POST['alamat'];
$uid         = $_POST['uid'];
$is_active   = $_POST['is_active'];
$createdBy   = $_SESSION['username'] ?? 'SYSTEM';

// 🔍 CEK UID
$cek = $conn->query("SELECT id_member FROM member_perpus WHERE uid = '$uid'");

if (!$cek) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Query error: ' . $conn->error
    ]);
    exit;
}

if ($cek->num_rows > 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'UID sudah terdaftar!'
    ]);
    exit;
}
// ✅ INSERT
$sql = "INSERT INTO member_perpus (nama_member,email,no_hp,alamat, uid, is_active, createdBy) 
        VALUES ('$nama_member','$email','$no_hp','$alamat', '$uid','$is_active', '$createdBy')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['status' => 'success', 'message' => 'Member berhasil ditambahkan']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menambahkan member: ' . $conn->error]);
}

$conn->close();
